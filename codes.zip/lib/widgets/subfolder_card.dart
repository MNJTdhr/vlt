// lib/widgets/subfolder_card.dart
import 'package:flutter/material.dart';
import 'package:vlt/models/vault_folder.dart';

class SubfolderCard extends StatelessWidget {
  final VaultFolder folder;
  final VoidCallback onTap;
  final void Function(VaultFolder folder, String newName)? onRename;
  final void Function(VaultFolder folder)? onDelete;
  final void Function(VaultFolder folder, IconData icon, Color color)?
      onCustomize;

  const SubfolderCard({
    super.key,
    required this.folder,
    required this.onTap,
    this.onRename,
    this.onDelete,
    this.onCustomize,
  });

  @override
  Widget build(BuildContext context) {
    return Card(
      elevation: 1,
      shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
      child: InkWell(
        borderRadius: BorderRadius.circular(12),
        onTap: onTap,
        child: Stack(
          children: [
            Padding(
              padding: const EdgeInsets.all(12),
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(folder.icon, color: folder.color, size: 32),
                  const SizedBox(height: 8),
                  Text(
                    folder.name,
                    textAlign: TextAlign.center,
                    overflow: TextOverflow.ellipsis,
                    maxLines: 1,
                    style: Theme.of(context).textTheme.bodyMedium?.copyWith(
                          fontWeight: FontWeight.w600,
                        ),
                  ),
                ],
              ),
            ),
            Positioned(
              top: 4,
              right: 4,
              child: PopupMenuButton<String>(
                icon: Icon(Icons.more_vert,
                    size: 20,
                    color: Theme.of(context)
                        .colorScheme
                        .onSurface
                        .withOpacity(0.6)),
                onSelected: (value) {
                  switch (value) {
                    case 'rename':
                      _showRenameDialog(context);
                      break;
                    case 'customize':
                      _showCustomizeDialog(context);
                      break;
                    case 'delete':
                      if (onDelete != null) onDelete!(folder);
                      break;
                  }
                },
                itemBuilder: (context) => const [
                  PopupMenuItem(
                    value: 'rename',
                    child: Row(
                      children: [
                        Icon(Icons.edit, size: 20),
                        SizedBox(width: 12),
                        Text('Rename'),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'customize',
                    child: Row(
                      children: [
                        Icon(Icons.palette, size: 20),
                        SizedBox(width: 12),
                        Text('Customize'),
                      ],
                    ),
                  ),
                  PopupMenuItem(
                    value: 'delete',
                    child: Row(
                      children: [
                        Icon(Icons.delete, size: 20, color: Colors.red),
                        SizedBox(width: 12),
                        Text('Delete', style: TextStyle(color: Colors.red)),
                      ],
                    ),
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }

  void _showRenameDialog(BuildContext context) {
    if (onRename == null) return;
    final controller = TextEditingController(text: folder.name);

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => SafeArea(
        child: Padding(
          padding: EdgeInsets.only(
            bottom: MediaQuery.of(context).viewInsets.bottom + 16,
            left: 24,
            right: 24,
            top: 24,
          ),
          child: Column(
            mainAxisSize: MainAxisSize.min,
            children: [
              TextField(
                controller: controller,
                autofocus: true,
                decoration: const InputDecoration(
                  labelText: 'Rename Folder',
                  border: OutlineInputBorder(),
                  prefixIcon: Icon(Icons.drive_file_rename_outline),
                ),
                onSubmitted: (value) {
                  if (value.trim().isNotEmpty) {
                    Navigator.pop(context);
                    onRename!(folder, value.trim());
                  }
                },
              ),
              const SizedBox(height: 16),
              FilledButton(
                onPressed: () {
                  final newName = controller.text.trim();
                  if (newName.isNotEmpty) {
                    Navigator.pop(context);
                    onRename!(folder, newName);
                  }
                },
                child: const Text('Rename'),
              ),
            ],
          ),
        ),
      ),
    );
  }

  void _showCustomizeDialog(BuildContext context) {
    if (onCustomize == null) return;

    IconData selectedIcon = folder.icon;
    Color selectedColor = folder.color;

    final availableIcons = [
      Icons.folder,
      Icons.photo_library,
      Icons.video_library,
      Icons.note,
      Icons.music_note,
      Icons.picture_as_pdf,
      Icons.description,
      Icons.archive,
      Icons.favorite,
      Icons.star,
      Icons.lock,
    ];

    final availableColors = [
      Colors.blue,
      Colors.red,
      Colors.green,
      Colors.orange,
      Colors.purple,
      Colors.teal,
      Colors.pink,
    ];

    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (_) => StatefulBuilder(
        builder: (context, setSheetState) => SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(24),
            child: Column(
              mainAxisSize: MainAxisSize.min,
              children: [
                Wrap(
                  spacing: 10,
                  children: availableIcons.map((icon) {
                    return IconButton(
                      icon: Icon(icon,
                          color: icon == selectedIcon
                              ? selectedColor
                              : Colors.grey),
                      onPressed: () =>
                          setSheetState(() => selectedIcon = icon),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                Wrap(
                  spacing: 10,
                  children: availableColors.map((color) {
                    final isSelected = color == selectedColor;
                    return GestureDetector(
                      onTap: () => setSheetState(() => selectedColor = color),
                      child: CircleAvatar(
                        radius: 16,
                        backgroundColor: color,
                        child: isSelected
                            ? const Icon(Icons.check, color: Colors.white, size: 16)
                            : null,
                      ),
                    );
                  }).toList(),
                ),
                const SizedBox(height: 16),
                FilledButton(
                  onPressed: () {
                    Navigator.pop(context);
                    onCustomize!(folder, selectedIcon, selectedColor);
                  },
                  child: const Text('Apply'),
                ),
              ],
            ),
          ),
        ),
      ),
    );
  }
}
