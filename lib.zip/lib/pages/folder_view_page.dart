// lib/pages/folder_view_page.dart
import 'dart:io';
import 'package:flutter/material.dart';
import 'package:file_picker/file_picker.dart';
import 'package:path/path.dart' as p;
import 'package:open_file/open_file.dart';
import 'package:vlt/widgets/folder_card.dart';
import 'package:vlt/widgets/folder_creator_sheet.dart';
import 'package:vlt/data/notifiers.dart' hide VaultFolder; // ✅ Clean fix
import 'package:vlt/utils/storage_helper.dart';
import 'package:vlt/models/vault_folder.dart';
import 'package:vlt/widgets/subfolder_card.dart';

class FolderViewPage extends StatefulWidget {
  final String folderName;

  const FolderViewPage({super.key, required this.folderName});

  @override
  State<FolderViewPage> createState() => _FolderViewPageState();
}

class _FolderViewPageState extends State<FolderViewPage>
    with SingleTickerProviderStateMixin {
  late VaultFolder currentFolder;
  List<FileSystemEntity> folderFiles = [];

  late AnimationController _fabAnimationController;
  bool isFabMenuOpen = false;

  @override
  void initState() {
    super.initState();

    // Get the current folder object using its name
    currentFolder = foldersNotifier.value.firstWhere(
      (f) => f.name == widget.folderName,
      orElse: () => foldersNotifier.value.first,
    );

    _fabAnimationController = AnimationController(
      vsync: this,
      duration: const Duration(milliseconds: 250),
    );

    _loadFolderFiles();
  }

  @override
  void dispose() {
    _fabAnimationController.dispose();
    super.dispose();
  }

  void _toggleFabMenu() {
    setState(() {
      isFabMenuOpen = !isFabMenuOpen;
      if (isFabMenuOpen) {
        _fabAnimationController.forward();
      } else {
        _fabAnimationController.reverse();
      }
    });
  }

  Future<void> _loadFolderFiles() async {
    final contents = await StorageHelper.getFolderContents(
      currentFolder.parentPath.isEmpty
          ? currentFolder.name
          : '${currentFolder.parentPath}/${currentFolder.name}',
    );
    setState(() {
      folderFiles = contents;
    });
  }

  void _openFile(File file) {
    OpenFile.open(file.path);
  }

  Future<void> _pickAndCopyFiles(FileType type) async {
    final result = await FilePicker.platform.pickFiles(
      allowMultiple: true,
      type: type,
    );

    if (result != null && result.files.isNotEmpty) {
      for (final file in result.files) {
        final path = file.path;
        if (path != null) {
          final originalFile = File(path);
          await StorageHelper.saveFileToVault(
            folderName: '${currentFolder.parentPath}/${currentFolder.name}'
                .replaceFirst(RegExp(r'^/'), ''),
            file: originalFile,
          );
        }
      }
      await _loadFolderFiles();

      if (!mounted) return;
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('${result.files.length} file(s) copied')),
      );
    }
  }

  Future<void> _handleOption(String type) async {
    if (isFabMenuOpen) _toggleFabMenu();

    switch (type) {
      case 'Add Images':
        await _pickAndCopyFiles(FileType.image);
        break;
      case 'Add Videos':
        await _pickAndCopyFiles(FileType.video);
        break;
      case 'Add Files':
        await _pickAndCopyFiles(FileType.any);
        break;
      case 'Add Folder':
        showModalBottomSheet(
          context: context,
          isScrollControlled: true,
          shape: const RoundedRectangleBorder(
            borderRadius: BorderRadius.vertical(top: Radius.circular(20)),
          ),
          builder: (ctx) => FolderCreatorSheet(
            parentPath: '${currentFolder.parentPath}/${currentFolder.name}'
                .replaceFirst(RegExp(r'^/'), ''),
            onFolderCreated: (folder) async {
              await _loadFolderFiles();
              setState(() {});
            },
          ),
        );

        break;
    }
  }

  // Display subfolders from metadata
  List<VaultFolder> _getSubfolders() {
    final fullCurrentPath = currentFolder.parentPath.isEmpty
        ? currentFolder.name
        : '${currentFolder.parentPath}/${currentFolder.name}';

    return foldersNotifier.value
        .where((f) => f.parentPath == fullCurrentPath)
        .toList();
  }

  Widget _buildVaultFolderCard(VaultFolder folder) {
  final isRootFolder = folder.parentPath == 'root' || folder.parentPath.isEmpty;

  if (isRootFolder) {
    return FolderCard(
      folder: folder,
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => FolderViewPage(folderName: folder.name),
          ),
        );
      },
      onRename: (f, newName) => _renameFolder(context, f, newName),
      onDelete: (f) => _deleteFolder(context, f),
      onCustomize: (f, icon, color) =>
          _customizeFolder(context, f, icon, color),
    );
  }

  return SubfolderCard(
    folder: folder,
    onTap: () {
      Navigator.push(
        context,
        MaterialPageRoute(
          builder: (_) => FolderViewPage(folderName: folder.name),
        ),
      );
    },
    onRename: (f, newName) => _renameFolder(context, f, newName),
    onDelete: (f) => _deleteFolder(context, f),
    onCustomize: (f, icon, color) =>
        _customizeFolder(context, f, icon, color),
  );
}



  @override
  Widget build(BuildContext context) {
    final subfolders = _getSubfolders();
    final isEmpty = folderFiles.whereType<File>().isEmpty && subfolders.isEmpty;

    return Scaffold(
      appBar: AppBar(
        title: Text(widget.folderName),
        backgroundColor: currentFolder.color,
        foregroundColor: Colors.white,
      ),
      body: isEmpty
          ? Center(
              child: Column(
                mainAxisAlignment: MainAxisAlignment.center,
                children: [
                  Icon(Icons.folder_open, size: 64, color: currentFolder.color),
                  const SizedBox(height: 16),
                  Text(
                    'The "${widget.folderName}" folder is empty.',
                    style: Theme.of(context).textTheme.titleMedium,
                  ),
                  const SizedBox(height: 8),
                  Text(
                    'Click the + button to add content.',
                    style: Theme.of(context).textTheme.bodyMedium,
                  ),
                ],
              ),
            )
          : Padding(
              padding: const EdgeInsets.all(12.0),
              child: GridView.builder(
                itemCount:
                    subfolders.length + folderFiles.whereType<File>().length,
                gridDelegate: const SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 3,
                  crossAxisSpacing: 8,
                  mainAxisSpacing: 8,
                ),
                itemBuilder: (context, index) {
                  if (index < subfolders.length) {
                    return _buildVaultFolderCard(subfolders[index]);
                  } else {
                    final file = folderFiles.whereType<File>().elementAt(
                      index - subfolders.length,
                    );
                    return ClipRRect(
                      borderRadius: BorderRadius.circular(8),
                      child: _buildThumbnail(file),
                    );
                  }
                },
              ),
            ),
      floatingActionButton: Column(
        mainAxisSize: MainAxisSize.min,
        crossAxisAlignment: CrossAxisAlignment.end,
        children: [
          AnimatedOpacity(
            opacity: isFabMenuOpen ? 1.0 : 0.0,
            duration: const Duration(milliseconds: 200),
            child: Visibility(
              visible: isFabMenuOpen,
              child: Column(
                mainAxisSize: MainAxisSize.min,
                crossAxisAlignment: CrossAxisAlignment.end,
                children: [
                  _buildMiniFab(
                    icon: Icons.folder,
                    label: 'Add Folder',
                    onPressed: () => _handleOption('Add Folder'),
                  ),
                  const SizedBox(height: 10),
                  _buildMiniFab(
                    icon: Icons.image,
                    label: 'Add Images',
                    onPressed: () => _handleOption('Add Images'),
                  ),
                  const SizedBox(height: 10),
                  _buildMiniFab(
                    icon: Icons.videocam,
                    label: 'Add Videos',
                    onPressed: () => _handleOption('Add Videos'),
                  ),
                  const SizedBox(height: 10),
                  _buildMiniFab(
                    icon: Icons.insert_drive_file,
                    label: 'Add Files',
                    onPressed: () => _handleOption('Add Files'),
                  ),
                  const SizedBox(height: 16),
                ],
              ),
            ),
          ),
          FloatingActionButton(
            onPressed: _toggleFabMenu,
            backgroundColor: currentFolder.color,
            child: RotationTransition(
              turns: Tween(
                begin: 0.0,
                end: 0.125,
              ).animate(_fabAnimationController),
              child: const Icon(Icons.add, color: Colors.white, size: 28),
            ),
          ),
        ],
      ),
    );
  }

  // Folder icon list used in subfolder creator
  final List<IconData> availableIcons = [
    Icons.folder,
    Icons.photo_library,
    Icons.video_library,
    Icons.note,
    Icons.music_note,
    Icons.picture_as_pdf,
    Icons.description,
    Icons.archive,
    Icons.favorite,
    Icons.star,
    Icons.lock,
  ];

  // Folder color palette
  final List<Color> availableColors = [
    Colors.blue,
    Colors.red,
    Colors.green,
    Colors.orange,
    Colors.purple,
    Colors.teal,
    Colors.pink,
  ];

  // Display card for legacy folder (if it exists on disk only)
  Widget _buildFolderCard(Directory dir) {
    final folderName = p.basename(dir.path);

    return GestureDetector(
      onTap: () {
        Navigator.push(
          context,
          MaterialPageRoute(
            builder: (_) => FolderViewPage(folderName: folderName),
          ),
        );
      },
      child: Card(
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(12)),
        elevation: 2,
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(Icons.folder, size: 36, color: currentFolder.color),
            const SizedBox(height: 8),
            Text(
              folderName,
              textAlign: TextAlign.center,
              overflow: TextOverflow.ellipsis,
              maxLines: 1,
            ),
          ],
        ),
      ),
    );
  }

  void _renameFolder(
    BuildContext context,
    VaultFolder folder,
    String newName,
  ) async {
    final currentFolders = List<VaultFolder>.from(foldersNotifier.value);
    final index = currentFolders.indexWhere((f) => f.id == folder.id);
    if (index != -1) {
      currentFolders[index] = folder.copyWith(name: newName);
      foldersNotifier.value = currentFolders;
      await StorageHelper.saveFoldersMetadata(currentFolders);
      setState(() {});
      if (mounted) {
        ScaffoldMessenger.of(
          context,
        ).showSnackBar(SnackBar(content: Text('Folder renamed to "$newName"')));
      }
    }
  }

  void _deleteFolder(BuildContext context, VaultFolder folder) async {
    final currentFolders = List<VaultFolder>.from(foldersNotifier.value);
    currentFolders.removeWhere((f) => f.id == folder.id);
    foldersNotifier.value = currentFolders;
    await StorageHelper.saveFoldersMetadata(currentFolders);
    setState(() {});
    if (mounted) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text('Folder "${folder.name}" deleted')),
      );
    }
  }

  void _customizeFolder(
    BuildContext context,
    VaultFolder folder,
    IconData icon,
    Color color,
  ) async {
    final currentFolders = List<VaultFolder>.from(foldersNotifier.value);
    final index = currentFolders.indexWhere((f) => f.id == folder.id);
    if (index != -1) {
      currentFolders[index] = folder.copyWith(icon: icon, color: color);
      foldersNotifier.value = currentFolders;
      await StorageHelper.saveFoldersMetadata(currentFolders);
      setState(() {});
      if (mounted) {
        ScaffoldMessenger.of(context).showSnackBar(
          SnackBar(content: Text('Folder "${folder.name}" customized')),
        );
      }
    }
  }

  // Shows a bottom sheet to create a new subfolder under the current folder

  Widget _buildThumbnail(File file) {
    final path = file.path;
    if (_isImage(path)) {
      return GestureDetector(
        onTap: () => _openFile(file),
        child: Image.file(file, fit: BoxFit.cover),
      );
    } else if (_isVideo(path)) {
      return GestureDetector(
        onTap: () => _openFile(file),
        child: Stack(
          fit: StackFit.expand,
          children: [
            Container(color: Colors.black12),
            const Center(
              child: Icon(Icons.play_circle, color: Colors.white, size: 36),
            ),
          ],
        ),
      );
    } else {
      return GestureDetector(
        onTap: () => _openFile(file),
        child: const Center(child: Icon(Icons.insert_drive_file, size: 40)),
      );
    }
  }

  bool _isImage(String path) => [
    '.jpg',
    '.jpeg',
    '.png',
    '.gif',
  ].contains(p.extension(path).toLowerCase());

  bool _isVideo(String path) =>
      ['.mp4', '.mov'].contains(p.extension(path).toLowerCase());

  Widget _buildMiniFab({
    required IconData icon,
    required String label,
    required VoidCallback onPressed,
  }) {
    return Row(
      mainAxisSize: MainAxisSize.min,
      children: [
        Container(
          padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 5),
          decoration: BoxDecoration(
            color: Colors.white,
            borderRadius: BorderRadius.circular(8),
            boxShadow: kElevationToShadow[1],
          ),
          child: Text(
            label,
            style: TextStyle(
              color: currentFolder.color,
              fontWeight: FontWeight.bold,
            ),
          ),
        ),
        const SizedBox(width: 12),
        SizedBox(
          width: 42,
          height: 42,
          child: FloatingActionButton(
            heroTag: null,
            onPressed: onPressed,
            backgroundColor: currentFolder.color,
            child: Icon(icon, color: Colors.white, size: 22),
          ),
        ),
      ],
    );
  }
}
